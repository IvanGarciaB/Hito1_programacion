import tienda as t

if __name__ == '__main__':
    t.main()



