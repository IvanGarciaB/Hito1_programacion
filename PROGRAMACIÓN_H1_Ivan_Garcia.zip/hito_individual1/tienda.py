import re
import random
from tabulate import tabulate

class Cliente:

    def __init__(self):
        conf = None
        print('Bienvenido a tu tienda de tecnología')
        print('A continuación introduzca su datos personales')
        while conf is None:
            self.nombre = input('Ingrese su nombre: ')
            self.apellido = input('Ingrese su apellido: ')

            print(f'Nombre: {self.nombre}')
            print(f'Apellido: {self.apellido}')

            conf = input('¿Estan bien? S o N: ')
            if conf.lower() != 's':
                conf = None
                print('Introduzca sus datos de nuevo')
            else:
                print('Usuario registrado correctamente')
class Productos:
    def __init__(self, codigo, nombre, precio, stock):
        self.codigo = codigo
        self.nombre = nombre
        self.precio = precio
        self.stock = stock



class Carrito:
    def __init__(self):
        self.lista_deseos = []
        self.productos= productos
        self.elegir = input('¿Desea comenzar con la comprar? S/N: ')
        if self.elegir.lower() =='s':
            self.lista_deseados()
        else:
            print('Esperamos verle de vuelta')
            exit()

    def lista_deseados(self):
        comp = None
        while comp is None:

            selec_produc = int(input('Ingrese el número del producto que desea agregar (o "0" para terminar): '))
            cantidad = int(input(f'Ingrese la cantidad del producto {productos[selec_produc -1].nombre}: '))
            if cantidad<=self.productos[selec_produc -1].stock:
                self.lista_deseos.append({'producto': productos[selec_produc - 1], 'cantidad': cantidad})
                print(f'Se han agregado {cantidad} {productos[selec_produc - 1].nombre} a la lista de deseos.')
                comp = input('¿Desea agregar algún otro producto? S/N: ')
                if comp.lower() == 's':
                    comp = None
                else:
                    self.pais = input('Ingrese su país: ')
                    if self.pais.lower() != 'españa':
                        self.iva = int(input('Cuál es el IVA de su país: '))
                        self.iva = self.iva / 100 + 1
                    else:
                        self.iva = 1.21
                    self.ciudad = input('Ingrese su ciudad: ')
                    self.calle = input('Ingrese su calle: ')
                    self.factura()



            else:
                print('No hay suficiente stock para este producto')
                comp = input('¿Desea agregar algún otro producto? S/N: ')
                if comp.lower() == 'n':
                    print('No ha agregado nada a su carrito, procede a salir de la aplicación')
                    exit()
                else:
                    comp = None



    def factura(self):
        subtotal = 0
        enviar = input('¿Desea recibir una factura a su email? S/N: ')
        if enviar.lower()=='s':
            print('--------------------------------------')
            print('A continuación aportenos su correo electrónico para enviarle la factura')
            self.correo = self.validar_correo(input('Correo electrónico: '))

            print('------FACTURA------')
            print(f'Correo: {self.correo}')
            print(f'País: {self.pais}')
            print(f'Ciudad: {self.ciudad}')
            print(f'Calle {self.calle}')

            print('Cantidad - Producto - Precio total x producto')
            for item in self.lista_deseos:
                producto = item['producto']
                cantidad = item['cantidad']
                precio_unitario = producto.precio
                total_producto = cantidad * precio_unitario
                print(f'{cantidad} - {producto.nombre} - {producto.precio * cantidad}€')

                subtotal += total_producto

            print('--------------------------------------')
            print(f'Subtotal: {subtotal}€')
            print(f'IVA: {round(self.iva * 100 - 100,0)}')
            print(f'El total con IVA incluido es: {round(subtotal*self.iva, 2)}€')
            self.seguimiento()
        else:
            for item in self.lista_deseos:
                producto = item['producto']
                cantidad = item['cantidad']
                precio_unitario = producto.precio
                total_producto = cantidad * precio_unitario
                subtotal += total_producto
            print(f'Su importe tota la pagar es de: {round(subtotal*self.iva, 2)}€')
            self.seguimiento()

    def seguimiento(self):
        print('----------------------------------------------')
        seguimiento = input('Desea recibir un código de seguimiento via SMS S/N: ')
        if seguimiento.lower()=='s':
            while True:
                self.telefono = input('Indiquenos su número de teléfono: ')
                if len(self.telefono) <=12:
                    break
                else:
                    print('Introduzca un numero de telefono menor o igual a 12 caracteres')

            numero_random = random.randint(800000, 899999)
            print('Aquí tiene el código de seguimeinto de su pedido')
            print(f'Su número de seguimiento es: {numero_random}')
            print(f'Cualquier notificación sobre su pedido se hara llegar al siguinete teléfono: {self.telefono}')
            print('Disfrute de su compra')
        else:
            print('Disfute de su compra')
            exit()
    def validar_correo(self, correo):
        patron_correo = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        while not patron_correo.match(correo):
            print('El formato del correo electrónico no es válido. Inténtelo nuevamente.')
            correo = input('Ingrese su correo electrónico: ')
        return correo

def mostrar_productos(productos):
    headers = ["Código", "Producto", "Precio (€)", "Stock"]
    table_data = [[producto.codigo, producto.nombre, producto.precio, producto.stock] for producto in productos]

    print(tabulate(table_data, headers=headers, tablefmt="grid"))

p1 = Productos(1, 'iPhone 15', 950, 10)
p2 = Productos(2,'Super Mario Bros Worder', 60, 25)
p3 = Productos(3,'Portatil Lenovo', 625, 20)
p4 = Productos(4,'Samsung Galaxy Tab S9', 819, 15)
p5 = Productos(5,'Tarjeta Riot Games', 20, 50)
p6 = Productos(6,'Monitor 24', 159, 30)
p7 = Productos(7,'Teclado mecánico', 75, 28)
productos = [p1, p2, p3, p4, p5, p6, p7]

def main():
    Cliente()
    mostrar_productos(productos)
    Carrito()
